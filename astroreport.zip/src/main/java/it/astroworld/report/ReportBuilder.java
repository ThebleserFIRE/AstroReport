package it.astroworld.report;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.Instant;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.ToDoubleFunction;

/** Trasforma i dati raccolti nel file JSON finale. */
final class ReportBuilder {
    private ReportBuilder() {
    }

    static final class Off {
        final String uuid;
        final String name;
        final long first;
        final long last;

        Off(String uuid, String name, long first, long last) {
            this.uuid = uuid;
            this.name = name;
            this.first = first;
            this.last = last;
        }
    }

    static final class Info {
        String serverName = "Server";
        String pluginVersion = "1.0.0";
        ZoneId zone = ZoneId.systemDefault();
        boolean finalReport;
        long nowMs;
        double hostRamMb;
        int hostCores;
        List<String> instructions = new ArrayList<>();
        List<Off> offline = new ArrayList<>();
        Map<String, Long> worldSizesMb = new LinkedHashMap<>();
        Map<String, Object> fullstats;
        Map<String, Map<String, Double>> history = new LinkedHashMap<>();
    }

    private static final String[] BUCKETS = {"notte (00-06)", "mattina (06-12)", "pomeriggio (12-18)", "sera (18-24)"};

    // ---------- punto d'ingresso ----------

    static Map<String, Object> build(Data d, Info in) {
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("istruzioni_per_claude", in.instructions);
        root.put("meta", meta(d, in));
        root.put("hardware", hardware(d, in));
        root.put("giocatori", players(d, in));
        root.put("mondo", world(d));
        root.put("confronto_mese_precedente", compare(d, in));
        if (in.fullstats != null) {
            root.put("dati_extra_fullstats", in.fullstats);
        }
        return root;
    }

    // ---------- meta ----------

    private static Map<String, Object> meta(Data d, Info in) {
        YearMonth ym = YearMonth.parse(d.month);
        long monthStart = ym.atDay(1).atStartOfDay(in.zone).toInstant().toEpochMilli();
        long monthEnd = ym.plusMonths(1).atDay(1).atStartOfDay(in.zone).toInstant().toEpochMilli();
        long end = in.finalReport ? monthEnd : in.nowMs;
        boolean partial = !in.finalReport || d.firstDataMs > monthStart + 86_400_000L;
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("server", in.serverName);
        m.put("mese", d.month);
        m.put("generato_il", fmt(in.nowMs, in.zone));
        m.put("report_finale", in.finalReport);
        m.put("dati_parziali", partial);
        m.put("raccolta_iniziata_il", fmt(d.firstDataMs, in.zone));
        m.put("giorni_di_raccolta", r1(Math.max(0, end - d.firstDataMs) / 86_400_000.0));
        m.put("fuso_orario", in.zone.getId());
        m.put("versione_plugin", in.pluginVersion);
        if (partial) {
            m.put("nota", "Il mese non è completo (report generato prima della fine del mese o raccolta iniziata dopo il giorno 1): "
                    + "i numeri vanno presentati come relativi al periodo raccolto.");
        }
        return m;
    }

    // ---------- hardware ----------

    private static Map<String, Object> hardware(Data d, Info in) {
        Map<String, Object> h = new LinkedHashMap<>();
        double n = Math.max(1, d.samples);
        h.put("campioni_raccolti", d.samples);

        Map<String, Object> ram = new LinkedHashMap<>();
        ram.put("heap_java_medio_mb", r(d.ramUsedSum / n));
        ram.put("heap_java_picco_mb", r(d.ramUsedMax));
        ram.put("heap_java_massimo_configurato_mb", r(d.ramMaxMb));
        if (d.rssSamples > 0) {
            ram.put("ram_processo_media_mb", r(d.rssSum / d.rssSamples));
            ram.put("ram_processo_picco_mb", r(d.rssMax));
        }
        if (in.hostRamMb > 0) {
            ram.put("ram_limite_host_mb", r(in.hostRamMb));
            double peak = d.rssSamples > 0 ? d.rssMax : d.ramUsedMax;
            ram.put("picco_percento_del_limite_host", r(100.0 * peak / in.hostRamMb));
        }
        h.put("memoria", ram);

        Map<String, Object> cpu = new LinkedHashMap<>();
        if (d.cpuSamples > 0) {
            cpu.put("processo_media_percento", r(d.cpuProcSum / d.cpuSamples));
            cpu.put("processo_picco_percento", r(d.cpuProcMax));
            cpu.put("sistema_media_percento", r(d.cpuSysSum / d.cpuSamples));
            cpu.put("sistema_picco_percento", r(d.cpuSysMax));
        }
        if (in.hostCores > 0) {
            cpu.put("core_host", in.hostCores);
        }
        h.put("cpu", cpu);

        Map<String, Object> tick = new LinkedHashMap<>();
        tick.put("tps_medio", r(d.tpsSum / n));
        tick.put("tps_minimo", r(d.tpsMin));
        tick.put("mspt_medio", r(d.msptSum / n));
        tick.put("mspt_picco", r(d.msptMax));
        tick.put("campioni_con_lag", d.lagSamples);
        tick.put("percento_tempo_con_lag", r(100.0 * d.lagSamples / n));
        h.put("prestazioni", tick);

        List<Object> peaks = new ArrayList<>();
        int i = 1;
        for (Data.Peak p : d.peaks) {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("posizione", i++);
            row.put("quando", fmt(p.ms, in.zone));
            row.put("tps", r(p.tps));
            row.put("mspt", r(p.mspt));
            row.put("ram_heap_mb", r(p.ramMb));
            if (p.rssMb > 0) {
                row.put("ram_processo_mb", r(p.rssMb));
            }
            if (p.cpuSys >= 0) {
                row.put("cpu_sistema_percento", r(p.cpuSys));
            }
            row.put("giocatori_online", p.online);
            row.put("entita_per_dimensione", p.entities);
            row.put("chunk_per_dimensione", p.chunks);
            row.put("causa_probabile", p.cause);
            peaks.add(row);
        }
        h.put("top_picchi_di_lag", peaks);
        h.put("nota_picchi", "I picchi sono rilevati con campionamenti periodici: i picchi più brevi possono sfuggire. "
                + "La causa è sempre 'probabile', dedotta dai dati disponibili in quel momento.");

        Map<String, Object> life = new LinkedHashMap<>();
        int starts = 0;
        int crashes = 0;
        Map<String, Long> stops = new LinkedHashMap<>();
        List<Object> events = new ArrayList<>();
        for (Data.Life l : d.life) {
            if (l.type.startsWith("avvio")) {
                starts++;
                if (l.type.equals("avvio_dopo_crash")) {
                    crashes++;
                }
            } else {
                stops.merge(l.type, 1L, Long::sum);
            }
            if (events.size() < 60) {
                Map<String, Object> ev = new LinkedHashMap<>();
                ev.put("quando", fmt(l.ms, in.zone));
                ev.put("tipo", l.type);
                events.add(ev);
            }
        }
        life.put("avvii_totali", starts);
        life.put("crash_rilevati", crashes);
        life.put("spegnimenti_per_tipo", stops);
        life.put("eventi", events);
        life.put("nota", "'riavvio_automatico_programmato' = spegnimento vicino a un orario configurato; "
                + "'console_o_pannello' = comando stop da console o pannello (manuale, oppure automatico se gli orari non sono configurati); "
                + "'manuale_admin_in_gioco' = un admin ha scritto stop o restart in gioco.");
        h.put("riavvii", life);

        Map<String, Object> adm = new LinkedHashMap<>();
        adm.put("comandi_admin_in_gioco", d.adminTotal);
        adm.put("comandi_da_console", d.consoleTotal);
        adm.put("top_comandi", topPairs(d.adminCmds, 10, "comando", "volte"));
        adm.put("per_admin", topPairs(d.adminBy, 10, "admin", "comandi"));
        h.put("comandi_admin", adm);

        h.put("dimensione_mondi_mb", in.worldSizesMb);
        return h;
    }

    // ---------- giocatori ----------

    private static Map<String, Object> players(Data d, Info in) {
        Map<String, Data.Pl> act = new LinkedHashMap<>();
        Set<String> activeUuids = new HashSet<>();
        for (Map.Entry<String, Data.Pl> en : d.players.entrySet()) {
            Data.Pl p = en.getValue();
            if (p.playSeconds > 0 || p.joins > 0) {
                String name = p.name;
                int k = 2;
                while (act.containsKey(name)) {
                    name = p.name + "#" + k++;
                }
                act.put(name, p);
                activeUuids.add(en.getKey());
            }
        }
        List<Map.Entry<String, Data.Pl>> list = new ArrayList<>(act.entrySet());
        double n = Math.max(1, d.samples);

        Map<String, Object> g = new LinkedHashMap<>();
        Map<String, Object> sum = new LinkedHashMap<>();
        sum.put("giocatori_attivi", act.size());

        YearMonth ym = YearMonth.parse(d.month);
        long monthStart = ym.atDay(1).atStartOfDay(in.zone).toInstant().toEpochMilli();
        long monthEnd = ym.plusMonths(1).atDay(1).atStartOfDay(in.zone).toInstant().toEpochMilli();
        List<Object> fresh = new ArrayList<>();
        for (Off o : in.offline) {
            if (o.first >= monthStart && o.first < monthEnd && o.name != null) {
                fresh.add(o.name);
            }
        }
        sum.put("nuovi_giocatori", fresh);

        Map<String, Object> peak = new LinkedHashMap<>();
        peak.put("giocatori", d.maxOnline);
        peak.put("quando", d.maxOnlineMs > 0 ? fmt(d.maxOnlineMs, in.zone) : null);
        sum.put("picco_contemporaneo", peak);
        sum.put("media_giocatori_online", r(d.onlineSum / n));

        double totalSec = 0;
        long pingSum = 0;
        long pingN = 0;
        for (Data.Pl p : act.values()) {
            totalSec += p.playSeconds;
            pingSum += p.pingSum;
            pingN += p.pingSamples;
        }
        sum.put("ore_gioco_totali", r1(totalSec / 3600.0));
        sum.put("ping_medio_ms", pingN > 0 ? r((double) pingSum / pingN) : null);

        List<Integer> hours = new ArrayList<>();
        for (int h = 0; h < 24; h++) {
            hours.add(h);
        }
        hours.sort((a, b) -> Long.compare(d.hourPlayerSec[b], d.hourPlayerSec[a]));
        List<Object> peakHours = new ArrayList<>();
        for (int i = 0; i < 3 && i < hours.size(); i++) {
            int h = hours.get(i);
            if (d.hourPlayerSec[h] <= 0) {
                break;
            }
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("fascia_oraria", String.format("%02d:00-%02d:00", h, (h + 1) % 24));
            row.put("ore_giocatore", r1(d.hourPlayerSec[h] / 3600.0));
            peakHours.add(row);
        }
        sum.put("ore_di_punta", peakHours);
        g.put("riepilogo", sum);

        Map<String, Object> rk = new LinkedHashMap<>();
        rk.put("tempo_di_gioco_ore", rank(list, p -> p.playSeconds / 3600.0, true));
        rk.put("mob_uccisi", rank(list, p -> p.mobKills, false));
        rk.put("uccisioni_pvp", rank(list, p -> p.playerKills, false));
        rk.put("morti", rank(list, p -> p.deaths, false));
        rk.put("blocchi_rotti", rank(list, p -> p.blocksBroken, false));
        rk.put("blocchi_piazzati", rank(list, p -> p.blocksPlaced, false));
        rk.put("accessi_al_server", rank(list, p -> p.joins, false));
        rk.put("messaggi_in_chat", rank(list, p -> p.chat, false));
        rk.put("comandi_eseguiti", rank(list, p -> p.commands, false));
        rk.put("sessione_piu_lunga_ore", rank(list, p -> p.longestSession / 3600.0, true));
        g.put("classifiche", rk);

        List<Map.Entry<String, Data.Pl>> byTime = new ArrayList<>(list);
        byTime.sort((a, b) -> Long.compare(b.getValue().playSeconds, a.getValue().playSeconds));
        List<Object> most = new ArrayList<>();
        for (int i = 0; i < 3 && i < byTime.size(); i++) {
            most.add(byTime.get(i).getKey());
        }
        List<Object> least = new ArrayList<>();
        for (int i = byTime.size() - 1; i >= 0 && least.size() < 3 && byTime.size() > 3; i--) {
            least.add(byTime.get(i).getKey());
        }
        g.put("piu_attivi", most);
        g.put("meno_attivi_tra_i_giocatori_attivi", least);

        List<Object> idle = new ArrayList<>();
        for (Off o : in.offline) {
            if (o.name != null && !activeUuids.contains(o.uuid) && idle.size() < 30) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("giocatore", o.name);
                row.put("ultimo_accesso", o.last > 0 ? fmt(o.last, in.zone) : null);
                idle.add(row);
            }
        }
        g.put("non_collegati_questo_mese", idle);

        g.put("tipologie", types(act));

        Map<String, Object> det = new LinkedHashMap<>();
        for (Map.Entry<String, Data.Pl> en : act.entrySet()) {
            Data.Pl p = en.getValue();
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("tempo_di_gioco", hms(p.playSeconds));
            row.put("ore_di_gioco", r1(p.playSeconds / 3600.0));
            row.put("accessi", p.joins);
            row.put("sessione_piu_lunga", hms(p.longestSession));
            row.put("mob_uccisi", p.mobKills);
            row.put("uccisioni_pvp", p.playerKills);
            row.put("morti", p.deaths);
            row.put("cause_morte", sorted(p.deathCauses));
            row.put("blocchi_rotti", p.blocksBroken);
            row.put("blocchi_piazzati", p.blocksPlaced);
            row.put("messaggi_in_chat", p.chat);
            row.put("comandi_eseguiti", p.commands);
            row.put("ping_medio_ms", p.pingSamples > 0 ? r((double) p.pingSum / p.pingSamples) : null);
            row.put("fascia_preferita", favourite(p));
            det.put(en.getKey(), row);
        }
        g.put("dettaglio_giocatori", det);
        g.put("nota", "Il contenuto delle chat non viene registrato: solo il numero di messaggi. Il tempo di gioco comprende anche l'inattività (AFK).");
        return g;
    }

    private static List<Object> types(Map<String, Data.Pl> act) {
        List<Object> out = new ArrayList<>();
        int n = act.size();
        if (n == 0) {
            return out;
        }
        double[] avg = new double[5];
        for (Data.Pl p : act.values()) {
            double[] v = values(p);
            for (int i = 0; i < 5; i++) {
                avg[i] += v[i];
            }
        }
        for (int i = 0; i < 5; i++) {
            avg[i] /= n;
        }
        String[] names = {"Minatore", "Costruttore", "Guerriero", "Chiacchierone", "Sfortunato"};
        String[] verb = {"ha rotto", "ha piazzato", "ha fatto", "ha scritto", "è morto"};
        String[] unit = {"blocchi", "blocchi", "uccisioni", "messaggi in chat", "volte"};
        for (Map.Entry<String, Data.Pl> en : act.entrySet()) {
            Data.Pl p = en.getValue();
            String tipo = "Equilibrato";
            String motivo = "Nessuna attività spicca in modo netto rispetto alla media del server";
            if (p.playSeconds < 3600) {
                tipo = "Fantasma";
                motivo = "Ha giocato meno di un'ora in tutto il mese";
            } else if (n > 1) {
                double[] v = values(p);
                int best = -1;
                double bestRatio = 0;
                for (int i = 0; i < 5; i++) {
                    double ratio = avg[i] > 0 ? v[i] / avg[i] : 0;
                    if (ratio > bestRatio) {
                        bestRatio = ratio;
                        best = i;
                    }
                }
                if (best >= 0 && bestRatio >= 1.3 && v[best] > 0) {
                    tipo = names[best];
                    motivo = verb[best] + " " + Math.round(v[best]) + " " + unit[best]
                            + " (media del server: " + Math.round(avg[best]) + ")";
                }
            }
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("giocatore", en.getKey());
            row.put("tipo", tipo);
            row.put("motivo", motivo);
            row.put("abitudine", habit(p));
            out.add(row);
        }
        return out;
    }

    private static double[] values(Data.Pl p) {
        return new double[] {p.blocksBroken, p.blocksPlaced, p.mobKills + p.playerKills, p.chat, p.deaths};
    }

    private static String habit(Data.Pl p) {
        long total = p.bucketSec[0] + p.bucketSec[1] + p.bucketSec[2] + p.bucketSec[3];
        if (total <= 0) {
            return "non disponibile";
        }
        double night = (p.bucketSec[0] + p.bucketSec[3]) / (double) total;
        double morning = p.bucketSec[1] / (double) total;
        if (night >= 0.7) {
            return "Nottambulo (gioca soprattutto di sera e di notte)";
        }
        if (morning >= 0.4) {
            return "Mattiniero (gioca molto di mattina)";
        }
        return "Gioca a tutte le ore";
    }

    private static String favourite(Data.Pl p) {
        int best = 0;
        for (int i = 1; i < 4; i++) {
            if (p.bucketSec[i] > p.bucketSec[best]) {
                best = i;
            }
        }
        return p.bucketSec[best] > 0 ? BUCKETS[best] : "non disponibile";
    }

    private static List<Object> rank(List<Map.Entry<String, Data.Pl>> list, ToDoubleFunction<Data.Pl> f, boolean oneDecimal) {
        List<Map.Entry<String, Data.Pl>> s = new ArrayList<>(list);
        s.sort((a, b) -> Double.compare(f.applyAsDouble(b.getValue()), f.applyAsDouble(a.getValue())));
        List<Object> out = new ArrayList<>();
        int pos = 1;
        for (Map.Entry<String, Data.Pl> en : s) {
            double v = f.applyAsDouble(en.getValue());
            if (v <= 0 || out.size() >= 10) {
                continue;
            }
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("posizione", pos++);
            row.put("giocatore", en.getKey());
            if (oneDecimal) {
                row.put("valore", r1(v));
            } else {
                row.put("valore", Math.round(v));
            }
            out.add(row);
        }
        return out;
    }

    // ---------- mondo ----------

    private static Map<String, Object> world(Data d) {
        Map<String, Object> w = new LinkedHashMap<>();
        List<String> keys = new ArrayList<>(d.dims.keySet());
        keys.sort((a, b) -> Integer.compare(order(a), order(b)) != 0 ? Integer.compare(order(a), order(b)) : a.compareTo(b));

        Map<String, Long> allMobCause = new HashMap<>();
        Map<String, Long> allMobType = new HashMap<>();
        Map<String, Long> allPlayerCause = new HashMap<>();
        Map<String, Object> perDim = new LinkedHashMap<>();
        for (String k : keys) {
            Data.Dim dm = d.dims.get(k);
            double hs = Math.max(1, dm.heavySamples);
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("entita_media", r(dm.entSum / hs));
            row.put("entita_max", dm.entMax);
            row.put("item_a_terra_media", r(dm.itemSum / hs));
            row.put("item_a_terra_max", dm.itemMax);
            row.put("mob_medi", r(dm.mobSum / hs));
            row.put("mob_max", dm.mobMax);
            row.put("chunk_caricati_medi", r(dm.chunkSum / hs));
            row.put("chunk_caricati_max", dm.chunkMax);
            row.put("ore_giocatore_totali", r1(dm.playerSec / 3600.0));
            row.put("blocchi_piazzati", dm.blocksPlaced);
            row.put("blocchi_rotti", dm.blocksBroken);
            row.put("morti_mob_totali", sumValues(dm.mobDeathsByCause));
            row.put("morti_mob_per_causa", sorted(dm.mobDeathsByCause));
            row.put("top_tipi_mob_morti", topPairs(dm.mobDeathsByType, 5, "tipo", "morti"));
            row.put("morti_giocatori_per_causa", sorted(dm.playerDeathsByCause));
            row.put("esplosioni_per_tipo", sorted(dm.explosions));
            perDim.put(k, row);
            dm.mobDeathsByCause.forEach((a, b) -> allMobCause.merge(a, b, Long::sum));
            dm.mobDeathsByType.forEach((a, b) -> allMobType.merge(a, b, Long::sum));
            dm.playerDeathsByCause.forEach((a, b) -> allPlayerCause.merge(a, b, Long::sum));
        }
        w.put("per_dimensione", perDim);

        Map<String, Object> tot = new LinkedHashMap<>();
        tot.put("morti_mob_totali", sumValues(allMobCause));
        tot.put("morti_mob_per_causa", sorted(allMobCause));
        tot.put("top_tipi_mob_morti", topPairs(allMobType, 8, "tipo", "morti"));
        tot.put("morti_giocatori_totali", sumValues(allPlayerCause));
        tot.put("morti_giocatori_per_causa", sorted(allPlayerCause));
        w.put("totali", tot);
        w.put("legenda_cause", "uccisi_dai_giocatori = ucciso da un giocatore (anche con archi o tridenti); fuoco_e_lava = fuoco, lava, pavimento rovente; "
                + "esplosioni = TNT o creeper senza un giocatore che colpisce direttamente (include le farm a TNT); "
                + "attacco_di_altri_mob = colpito da altri mob; cadute; annegamento_e_soffocamento; vuoto; altro; pvp (solo per i giocatori).");
        return w;
    }

    private static int order(String k) {
        switch (k) {
            case "overworld":
                return 0;
            case "nether":
                return 1;
            case "end":
                return 2;
            default:
                return 3;
        }
    }

    // ---------- confronto ----------

    static Map<String, Double> metrics(Data d) {
        Map<String, Double> m = new LinkedHashMap<>();
        double n = Math.max(1, d.samples);
        double totalSec = 0;
        double broken = 0;
        double placed = 0;
        double chat = 0;
        int active = 0;
        for (Data.Pl p : d.players.values()) {
            if (p.playSeconds > 0 || p.joins > 0) {
                active++;
            }
            totalSec += p.playSeconds;
            broken += p.blocksBroken;
            placed += p.blocksPlaced;
            chat += p.chat;
        }
        long mobDeaths = 0;
        long plDeaths = 0;
        for (Data.Dim dm : d.dims.values()) {
            mobDeaths += sumValues(dm.mobDeathsByCause);
            plDeaths += sumValues(dm.playerDeathsByCause);
        }
        int starts = 0;
        int crashes = 0;
        for (Data.Life l : d.life) {
            if (l.type.startsWith("avvio")) {
                starts++;
                if (l.type.equals("avvio_dopo_crash")) {
                    crashes++;
                }
            }
        }
        m.put("ram_processo_picco_mb", d.rssSamples > 0 ? d.rssMax : d.ramUsedMax);
        m.put("heap_java_picco_mb", d.ramUsedMax);
        m.put("cpu_processo_media_percento", d.cpuSamples > 0 ? d.cpuProcSum / d.cpuSamples : 0.0);
        m.put("tps_medio", d.tpsSum / n);
        m.put("mspt_medio", d.msptSum / n);
        m.put("percento_tempo_con_lag", 100.0 * d.lagSamples / n);
        m.put("giocatori_attivi", (double) active);
        m.put("ore_gioco_totali", totalSec / 3600.0);
        m.put("picco_giocatori_contemporanei", (double) d.maxOnline);
        m.put("morti_mob_totali", (double) mobDeaths);
        m.put("morti_giocatori_totali", (double) plDeaths);
        m.put("blocchi_rotti", broken);
        m.put("blocchi_piazzati", placed);
        m.put("messaggi_in_chat", chat);
        m.put("comandi_admin_in_gioco", (double) d.adminTotal);
        m.put("avvii_totali", (double) starts);
        m.put("crash_rilevati", (double) crashes);
        return m;
    }

    private static Map<String, Object> compare(Data d, Info in) {
        Map<String, Object> out = new LinkedHashMap<>();
        String prevMonth = YearMonth.parse(d.month).minusMonths(1).toString();
        Map<String, Double> prev = in.history.get(prevMonth);
        if (prev == null) {
            out.put("disponibile", false);
            out.put("nota", "Nessun dato del mese precedente: il confronto sarà disponibile dal secondo mese di raccolta completo.");
            return out;
        }
        out.put("disponibile", true);
        out.put("mese_precedente", prevMonth);
        Map<String, Double> cur = metrics(d);
        Map<String, Object> rows = new LinkedHashMap<>();
        for (Map.Entry<String, Double> en : cur.entrySet()) {
            Double before = prev.get(en.getKey());
            if (before == null) {
                continue;
            }
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("valore", r(en.getValue()));
            row.put("mese_precedente", r(before));
            row.put("differenza", r(en.getValue() - before));
            row.put("variazione_percento", before != 0 ? r(100.0 * (en.getValue() - before) / before) : null);
            rows.put(en.getKey(), row);
        }
        out.put("metriche", rows);
        return out;
    }

    // ---------- storico ----------

    @SuppressWarnings("unchecked")
    static Map<String, Map<String, Double>> loadHistory(File f) {
        Map<String, Map<String, Double>> h = new LinkedHashMap<>();
        if (!f.exists()) {
            return h;
        }
        try (ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f))) {
            Object o = oi.readObject();
            if (o instanceof Map<?, ?> m) {
                for (Map.Entry<?, ?> en : m.entrySet()) {
                    h.put(String.valueOf(en.getKey()), new LinkedHashMap<>((Map<String, Double>) en.getValue()));
                }
            }
        } catch (Exception ignored) {
            // storico illeggibile: si riparte da zero
        }
        return h;
    }

    static void saveHistory(File f, Map<String, Map<String, Double>> h) throws Exception {
        LinkedHashMap<String, LinkedHashMap<String, Double>> copy = new LinkedHashMap<>();
        for (Map.Entry<String, Map<String, Double>> en : h.entrySet()) {
            copy.put(en.getKey(), new LinkedHashMap<>(en.getValue()));
        }
        try (ObjectOutputStream oo = new ObjectOutputStream(new FileOutputStream(f))) {
            oo.writeObject(copy);
        }
    }

    // ---------- dati extra da FullStats ----------

    static Map<String, Object> fullStats(File db, String month, Map<String, String> names) {
        if (!db.exists()) {
            return null;
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("nota", "Dati letti in sola lettura dal database del plugin FullStats per questo mese. "
                + "Le chiavi sono nel formato CATEGORIA/STATISTICA e le unità non sono garantite: usali solo come dati extra "
                + "se sei sicuro del significato; i dati principali sono nelle altre sezioni.");
        Map<String, Map<String, Long>> per = new LinkedHashMap<>();
        try (Connection c = DriverManager.getConnection("jdbc:sqlite:" + db.getAbsolutePath())) {
            try (Statement st = c.createStatement()) {
                st.execute("PRAGMA query_only=ON");
            }
            YearMonth ym = YearMonth.parse(month);
            String sql = "SELECT uuid, cat, stat_key, SUM(amount) FROM stats WHERE day >= ? AND day <= ? "
                    + "GROUP BY uuid, cat, stat_key HAVING SUM(amount) > 0";
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setLong(1, ym.atDay(1).toEpochDay());
                ps.setLong(2, ym.atEndOfMonth().toEpochDay());
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        String uuid = rs.getString(1);
                        String name = names.getOrDefault(uuid, uuid);
                        per.computeIfAbsent(name, k -> new HashMap<>()).put(rs.getString(2) + "/" + rs.getString(3), rs.getLong(4));
                    }
                }
            }
        } catch (Throwable t) {
            out.put("errore", String.valueOf(t));
            return out;
        }
        Map<String, Object> players = new LinkedHashMap<>();
        for (Map.Entry<String, Map<String, Long>> en : per.entrySet()) {
            Map<String, Long> s = sorted(en.getValue());
            Map<String, Long> capped = new LinkedHashMap<>();
            for (Map.Entry<String, Long> x : s.entrySet()) {
                if (capped.size() >= 150) {
                    break;
                }
                capped.put(x.getKey(), x.getValue());
            }
            players.put(en.getKey(), capped);
        }
        out.put("giocatori", players);
        return out;
    }

    // ---------- helper ----------

    static String fmt(long ms, ZoneId zone) {
        return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(zone).format(Instant.ofEpochMilli(ms));
    }

    private static String hms(long sec) {
        return (sec / 3600) + "h " + ((sec % 3600) / 60) + "m";
    }

    private static double r(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    private static double r1(double v) {
        return Math.round(v * 10.0) / 10.0;
    }

    private static long sumValues(Map<String, Long> m) {
        long s = 0;
        for (long v : m.values()) {
            s += v;
        }
        return s;
    }

    private static Map<String, Long> sorted(Map<String, Long> m) {
        List<Map.Entry<String, Long>> l = new ArrayList<>(m.entrySet());
        l.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));
        Map<String, Long> out = new LinkedHashMap<>();
        for (Map.Entry<String, Long> en : l) {
            out.put(en.getKey(), en.getValue());
        }
        return out;
    }

    private static List<Object> topPairs(Map<String, Long> m, int max, String keyName, String valName) {
        List<Object> out = new ArrayList<>();
        for (Map.Entry<String, Long> en : sorted(m).entrySet()) {
            if (out.size() >= max) {
                break;
            }
            Map<String, Object> row = new LinkedHashMap<>();
            row.put(keyName, en.getKey());
            row.put(valName, en.getValue());
            out.add(row);
        }
        return out;
    }
}
