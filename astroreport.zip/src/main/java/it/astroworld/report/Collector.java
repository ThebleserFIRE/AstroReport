package it.astroworld.report;

import io.papermc.paper.event.player.AsyncChatEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.management.ManagementFactory;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.server.ServerCommandEvent;

/** Ascolta gli eventi del server e fa i campionamenti periodici. Tutti i metodi sono sincronizzati. */
final class Collector implements Listener {
    private final AstroReportPlugin plugin;
    private Data data;
    private final Map<UUID, Long> sessions = new HashMap<>();
    private String shutdownHint;

    Collector(AstroReportPlugin plugin, Data data) {
        this.plugin = plugin;
        this.data = data;
    }

    // ---------- accesso ai dati ----------

    synchronized Data data() {
        return data;
    }

    synchronized String month() {
        return data.month;
    }

    synchronized byte[] bytes() throws Exception {
        return Data.toBytes(data);
    }

    synchronized Data snapshot() throws Exception {
        Data c = Data.copy(data);
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, Long> en : sessions.entrySet()) {
            Data.Pl pl = c.player(en.getKey().toString());
            long sec = Math.max(0, (now - en.getValue()) / 1000);
            pl.playSeconds += sec;
            pl.longestSession = Math.max(pl.longestSession, sec);
        }
        return c;
    }

    synchronized Data rotate(String newMonth) {
        long now = System.currentTimeMillis();
        closeAllSessions(now);
        Data old = data;
        data = new Data(newMonth);
        data.running = old.running;
        data.firstDataMs = now;
        startSessionsForOnline();
        return old;
    }

    synchronized void addLife(String type) {
        data.life.add(new Data.Life(System.currentTimeMillis(), type));
    }

    synchronized void setRunning(boolean running) {
        data.running = running;
    }

    synchronized String takeShutdownHint() {
        String h = shutdownHint;
        shutdownHint = null;
        return h;
    }

    // ---------- sessioni ----------

    synchronized void startSessionsForOnline() {
        long now = System.currentTimeMillis();
        for (Player p : Bukkit.getOnlinePlayers()) {
            sessions.put(p.getUniqueId(), now);
            pl(p);
        }
    }

    synchronized void closeAllSessions(long now) {
        for (UUID id : new ArrayList<>(sessions.keySet())) {
            endSession(id, now);
        }
    }

    private void endSession(UUID id, long now) {
        Long start = sessions.remove(id);
        if (start == null) {
            return;
        }
        long sec = Math.max(0, (now - start) / 1000);
        Data.Pl pl = data.player(id.toString());
        pl.playSeconds += sec;
        pl.longestSession = Math.max(pl.longestSession, sec);
    }

    private Data.Pl pl(Player p) {
        Data.Pl pl = data.player(p.getUniqueId().toString());
        pl.name = p.getName();
        return pl;
    }

    private void touch() {
        if (data.firstDataMs == 0) {
            data.firstDataMs = System.currentTimeMillis();
        }
    }

    // ---------- utilità ----------

    static String dimKey(World w) {
        String env = String.valueOf(w.getEnvironment());
        switch (env) {
            case "NORMAL":
                return "overworld";
            case "NETHER":
                return "nether";
            case "THE_END":
                return "end";
            default:
                return w.getName();
        }
    }

    static String causeGroup(String cause) {
        switch (cause) {
            case "FIRE":
            case "FIRE_TICK":
            case "LAVA":
            case "HOT_FLOOR":
                return "fuoco_e_lava";
            case "BLOCK_EXPLOSION":
            case "ENTITY_EXPLOSION":
                return "esplosioni";
            case "FALL":
            case "FLY_INTO_WALL":
                return "cadute";
            case "DROWNING":
            case "SUFFOCATION":
            case "CRAMMING":
                return "annegamento_e_soffocamento";
            case "VOID":
                return "vuoto";
            case "ENTITY_ATTACK":
            case "ENTITY_SWEEP_ATTACK":
            case "PROJECTILE":
            case "THORNS":
                return "attacco_di_altri_mob";
            default:
                return "altro";
        }
    }

    private static String label(String raw) {
        String m = raw == null ? "" : raw.trim();
        if (m.startsWith("/")) {
            m = m.substring(1);
        }
        int sp = m.indexOf(' ');
        if (sp >= 0) {
            m = m.substring(0, sp);
        }
        int colon = m.indexOf(':');
        if (colon >= 0) {
            m = m.substring(colon + 1);
        }
        return m.toLowerCase(Locale.ROOT);
    }

    // ---------- eventi ----------

    @EventHandler(priority = EventPriority.MONITOR)
    public synchronized void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        touch();
        pl(p).joins++;
        sessions.put(p.getUniqueId(), System.currentTimeMillis());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public synchronized void onQuit(PlayerQuitEvent e) {
        endSession(e.getPlayer().getUniqueId(), System.currentTimeMillis());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public synchronized void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        pl(p).blocksBroken++;
        data.dim(dimKey(p.getWorld())).blocksBroken++;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public synchronized void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        pl(p).blocksPlaced++;
        data.dim(dimKey(p.getWorld())).blocksPlaced++;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public synchronized void onChat(AsyncChatEvent e) {
        pl(e.getPlayer()).chat++;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public synchronized void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        String l = label(e.getMessage());
        pl(p).commands++;
        if (p.isOp()) {
            data.adminTotal++;
            data.adminCmds.merge(l, 1L, Long::sum);
            data.adminBy.merge(p.getName(), 1L, Long::sum);
            if (l.equals("stop") || l.equals("restart")) {
                shutdownHint = "manuale_admin_in_gioco";
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public synchronized void onConsole(ServerCommandEvent e) {
        data.consoleTotal++;
        String l = label(e.getCommand());
        if ((l.equals("stop") || l.equals("restart")) && shutdownHint == null) {
            shutdownHint = "console_o_pannello";
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public synchronized void onDeath(EntityDeathEvent e) {
        LivingEntity le = e.getEntity();
        Data.Dim dm = data.dim(dimKey(le.getWorld()));
        EntityDamageEvent last = le.getLastDamageCause();
        String cause = last == null ? "UNKNOWN" : String.valueOf(last.getCause());
        if (le instanceof Player victim) {
            String grp = causeGroup(cause);
            Player killer = victim.getKiller();
            if (killer != null && !killer.equals(victim)) {
                grp = "pvp";
                pl(killer).playerKills++;
            }
            Data.Pl pl = pl(victim);
            pl.deaths++;
            pl.deathCauses.merge(grp, 1L, Long::sum);
            dm.playerDeathsByCause.merge(grp, 1L, Long::sum);
        } else if (le instanceof Mob) {
            Player killer = le.getKiller();
            String grp = killer != null ? "uccisi_dai_giocatori" : causeGroup(cause);
            dm.mobDeathsByCause.merge(grp, 1L, Long::sum);
            dm.mobDeathsByType.merge(String.valueOf(le.getType()), 1L, Long::sum);
            if (killer != null) {
                pl(killer).mobKills++;
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public synchronized void onExplode(EntityExplodeEvent e) {
        Entity en = e.getEntity();
        data.dim(dimKey(en.getWorld())).explosions.merge(String.valueOf(en.getType()), 1L, Long::sum);
    }

    // ---------- campionamento ----------

    synchronized void sample(boolean heavy, int intervalSec) {
        long now = System.currentTimeMillis();
        touch();
        ZonedDateTime zt = ZonedDateTime.now(plugin.zone());
        int hour = zt.getHour();
        int bucket = hour / 6;

        Runtime rt = Runtime.getRuntime();
        double used = (rt.totalMemory() - rt.freeMemory()) / 1048576.0;
        double max = rt.maxMemory() / 1048576.0;
        double rss = readRssMb();
        double cpuP = -1;
        double cpuS = -1;
        try {
            java.lang.management.OperatingSystemMXBean os = ManagementFactory.getOperatingSystemMXBean();
            if (os instanceof com.sun.management.OperatingSystemMXBean x) {
                cpuP = x.getProcessCpuLoad() * 100.0;
                cpuS = x.getCpuLoad() * 100.0;
            }
        } catch (Throwable ignored) {
            // CPU non disponibile su questo sistema
        }
        double[] t = Bukkit.getTPS();
        double tps = Math.min(20.0, t.length > 0 ? t[0] : 20.0);
        double mspt = Bukkit.getAverageTickTime();

        data.samples++;
        data.ramUsedSum += used;
        data.ramUsedMax = Math.max(data.ramUsedMax, used);
        data.ramMaxMb = max;
        if (rss > 0) {
            data.rssSum += rss;
            data.rssMax = Math.max(data.rssMax, rss);
            data.rssSamples++;
        }
        if (cpuP >= 0 && cpuS >= 0) {
            data.cpuProcSum += cpuP;
            data.cpuProcMax = Math.max(data.cpuProcMax, cpuP);
            data.cpuSysSum += cpuS;
            data.cpuSysMax = Math.max(data.cpuSysMax, cpuS);
            data.cpuSamples++;
        }
        data.tpsSum += tps;
        data.tpsMin = Math.min(data.tpsMin, tps);
        data.msptSum += mspt;
        data.msptMax = Math.max(data.msptMax, mspt);

        Collection<? extends Player> online = Bukkit.getOnlinePlayers();
        int n = online.size();
        data.onlineSum += n;
        if (n > data.maxOnline) {
            data.maxOnline = n;
            data.maxOnlineMs = now;
        }
        data.hourPlayerSec[hour] += (long) intervalSec * n;
        for (Player p : online) {
            Data.Pl pl = pl(p);
            pl.bucketSec[bucket] += intervalSec;
            pl.pingSum += p.getPing();
            pl.pingSamples++;
            data.dim(dimKey(p.getWorld())).playerSec += intervalSec;
        }

        boolean lag = mspt > 50.0 || tps < 17.5;
        if (lag) {
            data.lagSamples++;
        }
        if (!heavy && !lag) {
            return;
        }

        Map<String, Integer> ents = new HashMap<>();
        Map<String, Integer> items = new HashMap<>();
        Map<String, Integer> mobs = new HashMap<>();
        Map<String, Integer> chunks = new HashMap<>();
        for (World w : Bukkit.getWorlds()) {
            String key = dimKey(w);
            List<Entity> all = w.getEntities();
            int it = 0;
            int mb = 0;
            for (Entity en : all) {
                if (en instanceof Item) {
                    it++;
                } else if (en instanceof Mob) {
                    mb++;
                }
            }
            ents.merge(key, all.size(), Integer::sum);
            items.merge(key, it, Integer::sum);
            mobs.merge(key, mb, Integer::sum);
            chunks.merge(key, w.getLoadedChunks().length, Integer::sum);
        }

        if (heavy) {
            for (String key : ents.keySet()) {
                Data.Dim dm = data.dim(key);
                dm.heavySamples++;
                dm.entSum += ents.get(key);
                dm.itemSum += items.get(key);
                dm.mobSum += mobs.get(key);
                dm.chunkSum += chunks.get(key);
                dm.entMax = Math.max(dm.entMax, ents.get(key));
                dm.itemMax = Math.max(dm.itemMax, items.get(key));
                dm.mobMax = Math.max(dm.mobMax, mobs.get(key));
                dm.chunkMax = Math.max(dm.chunkMax, chunks.get(key));
            }
        }

        if (lag) {
            Data.Peak pk = new Data.Peak();
            pk.ms = now;
            pk.tps = tps;
            pk.mspt = mspt;
            pk.ramMb = used;
            pk.rssMb = rss;
            pk.cpuSys = cpuS;
            pk.online = n;
            pk.entities = ents;
            pk.chunks = chunks;
            pk.cause = guessCause(used, max, cpuS, n, ents, chunks);
            addPeak(pk, now);
        }
    }

    private void addPeak(Data.Peak pk, long now) {
        boolean add = true;
        for (Data.Peak x : new ArrayList<>(data.peaks)) {
            if (Math.abs(x.ms - now) < 300_000L) {
                if (pk.mspt > x.mspt) {
                    data.peaks.remove(x);
                } else {
                    add = false;
                }
            }
        }
        if (add) {
            data.peaks.add(pk);
            data.peaks.sort((a, b) -> Double.compare(b.mspt, a.mspt));
            while (data.peaks.size() > 10) {
                data.peaks.remove(data.peaks.size() - 1);
            }
        }
    }

    private String guessCause(double used, double max, double cpuS, int online,
                              Map<String, Integer> ents, Map<String, Integer> chunks) {
        List<String> r = new ArrayList<>();
        if (max > 0 && used / max > 0.90) {
            r.add("memoria Java quasi piena (" + Math.round(used) + " MB su " + Math.round(max)
                    + "), possibile pulizia della memoria");
        }
        int entTh = plugin.getConfig().getInt("lag.entity-threshold", 1200);
        int chTh = plugin.getConfig().getInt("lag.chunk-threshold", 1500);
        int plTh = plugin.getConfig().getInt("lag.players-threshold", 5);
        for (Map.Entry<String, Integer> en : ents.entrySet()) {
            if (en.getValue() > entTh) {
                r.add("molte entità in " + en.getKey() + " (" + en.getValue() + ")");
            }
        }
        for (Map.Entry<String, Integer> en : chunks.entrySet()) {
            if (en.getValue() > chTh) {
                r.add("molti chunk caricati in " + en.getKey() + " (" + en.getValue() + ")");
            }
        }
        if (online >= plTh) {
            r.add("molti giocatori online (" + online + ")");
        }
        if (cpuS >= 90) {
            r.add("CPU del server quasi al limite (" + Math.round(cpuS) + "%)");
        }
        if (r.isEmpty()) {
            r.add("nessun fattore evidente nei dati (possibili: generazione di nuovi chunk, redstone, plugin o carico dell'host)");
        }
        return String.join("; ", r);
    }

    private static double readRssMb() {
        try (BufferedReader br = new BufferedReader(new FileReader("/proc/self/status"))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("VmRSS:")) {
                    String[] p = line.trim().split("\\s+");
                    return Long.parseLong(p[1]) / 1024.0;
                }
            }
        } catch (Exception ignored) {
            // non è Linux o /proc non è leggibile
        }
        return -1;
    }
}
