package it.astroworld.report;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public final class AstroReportPlugin extends JavaPlugin {
    private Collector collector;
    private ZoneId zone = ZoneId.systemDefault();
    private File stateFile;
    private File historyFile;
    private File reportsDir;
    private int tickCounter;

    ZoneId zone() {
        return zone;
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        try {
            zone = ZoneId.of(getConfig().getString("timezone", "Europe/Rome"));
        } catch (Exception e) {
            getLogger().warning("Fuso orario non valido nella config, uso quello del server.");
            zone = ZoneId.systemDefault();
        }
        getDataFolder().mkdirs();
        stateFile = new File(getDataFolder(), "state.dat");
        historyFile = new File(getDataFolder(), "history.dat");
        reportsDir = new File(getDataFolder(), "reports");
        reportsDir.mkdirs();

        long now = System.currentTimeMillis();
        String currentMonth = YearMonth.now(zone).toString();
        Data loaded = loadState();
        boolean crashed = false;
        Data oldMonth = null;
        if (loaded == null) {
            loaded = new Data(currentMonth);
        } else {
            crashed = loaded.running;
            if (!currentMonth.equals(loaded.month)) {
                oldMonth = loaded;
                loaded = new Data(currentMonth);
            }
        }
        loaded.running = true;
        if (loaded.firstDataMs == 0) {
            loaded.firstDataMs = now;
        }
        loaded.life.add(new Data.Life(now, crashed ? "avvio_dopo_crash" : "avvio_normale"));

        collector = new Collector(this, loaded);
        getServer().getPluginManager().registerEvents(collector, this);
        collector.startSessionsForOnline();
        saveStateSync();
        if (oldMonth != null) {
            generateReport(oldMonth, true, null);
        }

        int light = Math.max(5, getConfig().getInt("sample-interval-seconds", 15));
        int heavyEvery = Math.max(light, getConfig().getInt("heavy-interval-seconds", 300));
        final int ratio = Math.max(1, heavyEvery / light);
        getServer().getScheduler().runTaskTimer(this, () -> {
            tickCounter++;
            collector.sample(tickCounter % ratio == 0, light);
        }, 20L * light, 20L * light);
        getServer().getScheduler().runTaskTimer(this, () -> checkRollover(), 1200L, 1200L);
        getServer().getScheduler().runTaskTimer(this, () -> saveStateAsync(), 6000L, 6000L);
        getLogger().info("AstroReport attivo. Mese in raccolta: " + collector.month());
    }

    @Override
    public void onDisable() {
        if (collector == null) {
            return;
        }
        collector.closeAllSessions(System.currentTimeMillis());
        collector.addLife(classifyShutdown());
        collector.setRunning(false);
        saveStateSync();
    }

    // ---------- comandi ----------

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("astroreport.admin")) {
            sender.sendMessage(Component.text("Non hai il permesso di usare questo comando."));
            return true;
        }
        String sub = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "help";
        switch (sub) {
            case "now":
                try {
                    Data snap = collector.snapshot();
                    sender.sendMessage(Component.text("Genero il report parziale del mese " + snap.month + "..."));
                    generateReport(snap, false, sender);
                } catch (Exception e) {
                    sender.sendMessage(Component.text("Errore: " + e));
                    getLogger().log(Level.WARNING, "Errore nella generazione del report", e);
                }
                return true;
            case "save":
                saveStateAsync();
                sender.sendMessage(Component.text("Stato salvato."));
                return true;
            case "status":
                Data d = collector.data();
                sender.sendMessage(Component.text("Mese: " + collector.month() + " | campioni: " + d.samples
                        + " | picchi registrati: " + d.peaks.size() + " | giocatori visti: " + d.players.size()));
                return true;
            default:
                sender.sendMessage(Component.text("Uso: /astroreport <now|status|save>"));
                return true;
        }
    }

    // ---------- ciclo di vita ----------

    private String classifyShutdown() {
        String hint = collector.takeShutdownHint();
        if ("manuale_admin_in_gioco".equals(hint)) {
            return hint;
        }
        int tolerance = getConfig().getInt("auto-restart-tolerance-minutes", 10);
        LocalTime now = LocalTime.now(zone);
        for (String s : getConfig().getStringList("auto-restart-times")) {
            try {
                LocalTime t = LocalTime.parse(s.trim());
                long diff = Math.abs(Duration.between(t, now).toMinutes());
                diff = Math.min(diff, 1440 - diff);
                if (diff <= tolerance) {
                    return "riavvio_automatico_programmato";
                }
            } catch (Exception ignored) {
                // orario scritto male nella config
            }
        }
        return hint != null ? hint : "spegnimento_senza_comando_registrato";
    }

    private void checkRollover() {
        String cur = YearMonth.now(zone).toString();
        if (cur.equals(collector.month())) {
            return;
        }
        Data old = collector.rotate(cur);
        saveStateAsync();
        generateReport(old, true, null);
    }

    // ---------- salvataggio stato ----------

    private Data loadState() {
        if (!stateFile.exists()) {
            return null;
        }
        try {
            return Data.fromBytes(Files.readAllBytes(stateFile.toPath()));
        } catch (Throwable t) {
            getLogger().warning("Impossibile leggere state.dat (" + t + "), riparto da zero. Copia di sicurezza: state.corrupt");
            try {
                Files.copy(stateFile.toPath(), new File(getDataFolder(), "state.corrupt").toPath(),
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (Exception ignored) {
                // pazienza
            }
            return null;
        }
    }

    private void writeState(byte[] bytes) {
        try {
            File tmp = new File(getDataFolder(), "state.tmp");
            Files.write(tmp.toPath(), bytes);
            Files.move(tmp.toPath(), stateFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "Salvataggio dello stato non riuscito", e);
        }
    }

    private void saveStateSync() {
        try {
            writeState(collector.bytes());
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "Salvataggio dello stato non riuscito", e);
        }
    }

    private void saveStateAsync() {
        try {
            final byte[] b = collector.bytes();
            getServer().getScheduler().runTaskAsynchronously(this, () -> writeState(b));
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "Salvataggio dello stato non riuscito", e);
        }
    }

    // ---------- generazione del report ----------

    private void generateReport(Data snapshot, boolean finalReport, CommandSender notify) {
        final ReportBuilder.Info info = new ReportBuilder.Info();
        info.serverName = getConfig().getString("server-name", "Astroworld");
        info.pluginVersion = getPluginMeta().getVersion();
        info.zone = zone;
        info.finalReport = finalReport;
        info.nowMs = System.currentTimeMillis();
        info.hostRamMb = getConfig().getDouble("host.ram-limit-mb", 12288);
        info.hostCores = getConfig().getInt("host.cpu-cores", 4);
        info.instructions = loadInstructions();

        final Map<String, String> names = new HashMap<>();
        for (OfflinePlayer op : Bukkit.getOfflinePlayers()) {
            if (op.getName() != null) {
                names.put(op.getUniqueId().toString(), op.getName());
                info.offline.add(new ReportBuilder.Off(op.getUniqueId().toString(), op.getName(),
                        op.getFirstPlayed(), op.getLastPlayed()));
            }
        }
        for (Map.Entry<String, Data.Pl> en : snapshot.players.entrySet()) {
            names.put(en.getKey(), en.getValue().name);
        }
        final Map<String, List<File>> folders = new LinkedHashMap<>();
        for (World w : Bukkit.getWorlds()) {
            folders.computeIfAbsent(Collector.dimKey(w), k -> new ArrayList<>()).add(w.getWorldFolder());
        }
        final boolean useFullStats = getConfig().getBoolean("fullstats-import", true);
        final File fsDb = new File(getDataFolder().getParentFile(), "FullStats" + File.separator + "stats.db");

        getServer().getScheduler().runTaskAsynchronously(this, () -> {
            try {
                for (Map.Entry<String, List<File>> en : folders.entrySet()) {
                    long total = 0;
                    for (File f : en.getValue()) {
                        total += dirSize(f);
                    }
                    info.worldSizesMb.put(en.getKey(), total / 1048576L);
                }
                info.history = ReportBuilder.loadHistory(historyFile);
                if (useFullStats) {
                    info.fullstats = ReportBuilder.fullStats(fsDb, snapshot.month, names);
                }
                Map<String, Object> report = ReportBuilder.build(snapshot, info);
                String name = "AstroReport-" + snapshot.month + (finalReport ? "" : "-parziale") + ".json";
                File out = new File(reportsDir, name);
                Files.writeString(out.toPath(), Json.write(report), StandardCharsets.UTF_8);
                if (finalReport) {
                    info.history.put(snapshot.month, ReportBuilder.metrics(snapshot));
                    ReportBuilder.saveHistory(historyFile, info.history);
                }
                getLogger().info("Report creato: plugins/AstroReport/reports/" + name);
                if (notify != null) {
                    getServer().getScheduler().runTask(this, () ->
                            notify.sendMessage(Component.text("Report creato: plugins/AstroReport/reports/" + name)));
                }
            } catch (Throwable t) {
                getLogger().log(Level.SEVERE, "Errore nella generazione del report", t);
                if (notify != null) {
                    getServer().getScheduler().runTask(this, () ->
                            notify.sendMessage(Component.text("Errore nella generazione del report, vedi la console.")));
                }
            }
        });
    }

    private List<String> loadInstructions() {
        List<String> lines = new ArrayList<>();
        try (InputStream in = getResource("istruzioni.txt")) {
            if (in != null) {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                    String l;
                    while ((l = br.readLine()) != null) {
                        lines.add(l);
                    }
                }
            }
        } catch (Exception ignored) {
            // istruzioni non disponibili
        }
        return lines;
    }

    private static long dirSize(File f) {
        if (f == null || !f.exists()) {
            return 0;
        }
        if (f.isFile()) {
            return f.length();
        }
        long total = 0;
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) {
                total += dirSize(k);
            }
        }
        return total;
    }
}
