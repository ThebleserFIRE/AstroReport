package it.astroworld.report;

import java.util.Collection;
import java.util.Map;

/** Scrittore JSON minimale (senza librerie esterne). */
final class Json {
    private Json() {
    }

    static String write(Object o) {
        StringBuilder sb = new StringBuilder();
        value(sb, o, 0);
        sb.append('\n');
        return sb.toString();
    }

    private static void value(StringBuilder sb, Object o, int ind) {
        if (o == null) {
            sb.append("null");
        } else if (o instanceof String s) {
            str(sb, s);
        } else if (o instanceof Boolean b) {
            sb.append(b.booleanValue());
        } else if (o instanceof Double || o instanceof Float) {
            double d = ((Number) o).doubleValue();
            if (Double.isNaN(d) || Double.isInfinite(d)) {
                sb.append("null");
            } else {
                double r = Math.round(d * 100.0) / 100.0;
                if (r == Math.rint(r) && Math.abs(r) < 1e15) {
                    sb.append((long) r);
                } else {
                    sb.append(r);
                }
            }
        } else if (o instanceof Number n) {
            sb.append(n.longValue());
        } else if (o instanceof Map<?, ?> m) {
            map(sb, m, ind);
        } else if (o instanceof Collection<?> c) {
            list(sb, c, ind);
        } else {
            str(sb, String.valueOf(o));
        }
    }

    private static void map(StringBuilder sb, Map<?, ?> m, int ind) {
        if (m.isEmpty()) {
            sb.append("{}");
            return;
        }
        sb.append("{\n");
        int i = 0;
        for (Map.Entry<?, ?> en : m.entrySet()) {
            pad(sb, ind + 1);
            str(sb, String.valueOf(en.getKey()));
            sb.append(": ");
            value(sb, en.getValue(), ind + 1);
            if (++i < m.size()) {
                sb.append(',');
            }
            sb.append('\n');
        }
        pad(sb, ind);
        sb.append('}');
    }

    private static void list(StringBuilder sb, Collection<?> c, int ind) {
        if (c.isEmpty()) {
            sb.append("[]");
            return;
        }
        boolean simple = true;
        for (Object x : c) {
            if (x instanceof Map || x instanceof Collection) {
                simple = false;
                break;
            }
        }
        if (simple && !(c.iterator().next() instanceof String)) {
            sb.append('[');
            int i = 0;
            for (Object x : c) {
                value(sb, x, ind);
                if (++i < c.size()) {
                    sb.append(", ");
                }
            }
            sb.append(']');
            return;
        }
        sb.append("[\n");
        int i = 0;
        for (Object x : c) {
            pad(sb, ind + 1);
            value(sb, x, ind + 1);
            if (++i < c.size()) {
                sb.append(',');
            }
            sb.append('\n');
        }
        pad(sb, ind);
        sb.append(']');
    }

    private static void pad(StringBuilder sb, int ind) {
        for (int i = 0; i < ind; i++) {
            sb.append("  ");
        }
    }

    private static void str(StringBuilder sb, String s) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            switch (ch) {
                case '"':
                    sb.append("\\\"");
                    break;
                case '\\':
                    sb.append("\\\\");
                    break;
                case '\n':
                    sb.append("\\n");
                    break;
                case '\r':
                    sb.append("\\r");
                    break;
                case '\t':
                    sb.append("\\t");
                    break;
                default:
                    if (ch < 0x20) {
                        sb.append(String.format("\\u%04x", (int) ch));
                    } else {
                        sb.append(ch);
                    }
            }
        }
        sb.append('"');
    }
}
