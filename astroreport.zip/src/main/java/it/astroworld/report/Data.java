package it.astroworld.report;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Tutti i dati raccolti nel mese corrente. Viene salvato su disco con la serializzazione Java. */
final class Data implements Serializable {
    private static final long serialVersionUID = 1L;

    String month;
    boolean running;
    long firstDataMs;

    // hardware
    int samples;
    double ramUsedSum, ramUsedMax, ramMaxMb;
    double rssSum, rssMax;
    int rssSamples;
    double cpuProcSum, cpuProcMax, cpuSysSum, cpuSysMax;
    int cpuSamples;
    double tpsSum, tpsMin = 20.0, msptSum, msptMax;
    int lagSamples;
    List<Peak> peaks = new ArrayList<>();
    List<Life> life = new ArrayList<>();

    // comandi
    Map<String, Long> adminCmds = new HashMap<>();
    Map<String, Long> adminBy = new HashMap<>();
    long adminTotal;
    long consoleTotal;

    // giocatori online
    int maxOnline;
    long maxOnlineMs;
    long onlineSum;
    long[] hourPlayerSec = new long[24];
    Map<String, Pl> players = new HashMap<>();

    // mondo
    Map<String, Dim> dims = new HashMap<>();

    Data(String month) {
        this.month = month;
    }

    Pl player(String uuid) {
        return players.computeIfAbsent(uuid, k -> new Pl());
    }

    Dim dim(String key) {
        return dims.computeIfAbsent(key, k -> new Dim());
    }

    static byte[] toBytes(Data d) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try (ObjectOutputStream oo = new ObjectOutputStream(bo)) {
            oo.writeObject(d);
        }
        return bo.toByteArray();
    }

    static Data fromBytes(byte[] b) throws Exception {
        try (ObjectInputStream oi = new ObjectInputStream(new ByteArrayInputStream(b))) {
            return (Data) oi.readObject();
        }
    }

    static Data copy(Data d) throws Exception {
        return fromBytes(toBytes(d));
    }

    static final class Pl implements Serializable {
        private static final long serialVersionUID = 1L;
        String name = "?";
        long playSeconds;
        long longestSession;
        int joins;
        int mobKills, playerKills, deaths;
        long blocksBroken, blocksPlaced;
        int chat, commands;
        long pingSum;
        int pingSamples;
        long[] bucketSec = new long[4];
        Map<String, Long> deathCauses = new HashMap<>();
    }

    static final class Dim implements Serializable {
        private static final long serialVersionUID = 1L;
        int heavySamples;
        long entSum, itemSum, mobSum, chunkSum;
        int entMax, itemMax, mobMax, chunkMax;
        long playerSec;
        long blocksPlaced, blocksBroken;
        Map<String, Long> mobDeathsByCause = new HashMap<>();
        Map<String, Long> mobDeathsByType = new HashMap<>();
        Map<String, Long> playerDeathsByCause = new HashMap<>();
        Map<String, Long> explosions = new HashMap<>();
    }

    static final class Peak implements Serializable {
        private static final long serialVersionUID = 1L;
        long ms;
        double tps, mspt, ramMb, rssMb, cpuSys;
        int online;
        Map<String, Integer> entities = new HashMap<>();
        Map<String, Integer> chunks = new HashMap<>();
        String cause = "";
    }

    static final class Life implements Serializable {
        private static final long serialVersionUID = 1L;
        long ms;
        String type;

        Life(long ms, String type) {
            this.ms = ms;
            this.type = type;
        }
    }
}
